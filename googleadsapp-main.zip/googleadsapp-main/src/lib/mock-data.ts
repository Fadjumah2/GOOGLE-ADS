export type Campaign = {
  id: string;
  name: string;
  status: "ENABLED" | "PAUSED" | "REMOVED";
  budget: number;
  clicks: number;
  impressions: number;
  cost: number;
  conversions: number;
  ctr: number;
  roas: number;
};

export const campaigns: Campaign[] = [
  { id: "21847001", name: "Brand — Search (US/CA)", status: "ENABLED", budget: 250, clicks: 12840, impressions: 184320, cost: 4218.55, conversions: 612, ctr: 6.97, roas: 4.8 },
  { id: "21847002", name: "Performance Max — Holiday Push", status: "ENABLED", budget: 800, clicks: 28140, impressions: 612480, cost: 18920.10, conversions: 1842, ctr: 4.59, roas: 3.2 },
  { id: "21847003", name: "Competitor Conquesting", status: "PAUSED", budget: 120, clicks: 3210, impressions: 92140, cost: 1840.20, conversions: 88, ctr: 3.48, roas: 1.4 },
  { id: "21847004", name: "Retargeting — Cart Abandon", status: "ENABLED", budget: 180, clicks: 6420, impressions: 142000, cost: 2412.80, conversions: 421, ctr: 4.52, roas: 6.1 },
  { id: "21847005", name: "Generic — Long Tail Discovery", status: "ENABLED", budget: 340, clicks: 18230, impressions: 412800, cost: 6840.90, conversions: 312, ctr: 4.41, roas: 1.9 },
  { id: "21847006", name: "Display — Awareness Q4", status: "PAUSED", budget: 90, clicks: 1840, impressions: 284120, cost: 612.10, conversions: 22, ctr: 0.65, roas: 0.8 },
];

export const spendTrend = [
  { day: "Mon", spend: 4120, clicks: 8240, conversions: 312 },
  { day: "Tue", spend: 4820, clicks: 9120, conversions: 358 },
  { day: "Wed", spend: 5240, clicks: 10240, conversions: 412 },
  { day: "Thu", spend: 4910, clicks: 9680, conversions: 389 },
  { day: "Fri", spend: 6120, clicks: 11820, conversions: 472 },
  { day: "Sat", spend: 6840, clicks: 12420, conversions: 521 },
  { day: "Sun", spend: 5980, clicks: 11020, conversions: 458 },
];

export const channelMix = [
  { name: "Search", value: 48 },
  { name: "PMax", value: 27 },
  { name: "Display", value: 14 },
  { name: "Retarget", value: 11 },
];

export type AgentRun = {
  id: string;
  agent: "ROI Sentry" | "Intent Surgeon" | "Persuasion Architect";
  action: string;
  campaign: string;
  impact: string;
  status: "applied" | "queued" | "reverted";
  at: string;
};

export const agentRuns: AgentRun[] = [
  { id: "r-9012", agent: "Intent Surgeon", action: "Injected 14 negative keywords", campaign: "Generic — Long Tail Discovery", impact: "-$182/day waste", status: "applied", at: "2m ago" },
  { id: "r-9011", agent: "Persuasion Architect", action: "Rewrote 3 RSA headlines", campaign: "Brand — Search (US/CA)", impact: "+12% est. CTR", status: "applied", at: "14m ago" },
  { id: "r-9010", agent: "ROI Sentry", action: "Raised budget cap +20%", campaign: "Retargeting — Cart Abandon", impact: "ROAS 6.1x", status: "applied", at: "1h ago" },
  { id: "r-9009", agent: "ROI Sentry", action: "Paused underperforming ad group", campaign: "Display — Awareness Q4", impact: "-$94/day waste", status: "applied", at: "3h ago" },
  { id: "r-9008", agent: "Intent Surgeon", action: "Flagged 9 irrelevant search terms", campaign: "Performance Max — Holiday Push", impact: "Pending review", status: "queued", at: "5h ago" },
  { id: "r-9007", agent: "Persuasion Architect", action: "Generated 6 description variants", campaign: "Competitor Conquesting", impact: "A/B queued", status: "queued", at: "8h ago" },
];

export const agents = [
  {
    key: "roi-sentry",
    name: "ROI Sentry",
    role: "Budget & Performance Guard",
    description: "Monitors cost, conversions and budget pacing. Pauses bleeding ad groups, scales winners.",
    status: "active" as const,
    runs24h: 42,
    saved: 1842.10,
    accent: "primary" as const,
  },
  {
    key: "intent-surgeon",
    name: "Intent Surgeon",
    role: "Negative Keyword Surgeon",
    description: "Analyzes search term reports and surgically removes wasteful queries via negative keywords.",
    status: "active" as const,
    runs24h: 18,
    saved: 942.40,
    accent: "accent" as const,
  },
  {
    key: "persuasion-architect",
    name: "Persuasion Architect",
    role: "Creative Optimizer (Gemini)",
    description: "Uses Gemini to rewrite headlines & descriptions. Pushes winners to ENABLED ads.",
    status: "active" as const,
    runs24h: 9,
    saved: 0,
    accent: "success" as const,
  },
];

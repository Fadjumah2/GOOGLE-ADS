import { createFileRoute } from "@tanstack/react-router";
import { KeyRound, Database, Bot, Save } from "lucide-react";

export const Route = createFileRoute("/settings")({
  component: SettingsPage,
  head: () => ({ meta: [{ title: "Settings — Synapse" }] }),
});

const sections = [
  { icon: KeyRound, title: "Google Ads API", desc: "OAuth client, developer token, refresh token, login customer ID.", fields: ["GOOGLE_CLIENT_ID", "GOOGLE_CLIENT_SECRET", "DEVELOPER_TOKEN", "GOOGLE_REFRESH_TOKEN"] },
  { icon: Bot, title: "Gemini AI", desc: "API key powering Persuasion Architect copy generation.", fields: ["GEMINI_API_KEY"] },
  { icon: Database, title: "Postgres", desc: "Audit log & campaign config persistence.", fields: ["DATABASE_URL"] },
];

function SettingsPage() {
  return (
    <div className="mx-auto max-w-4xl space-y-6 p-6 md:p-8">
      <header>
        <h1 className="font-display text-3xl font-semibold tracking-tight">Settings</h1>
        <p className="text-sm text-muted-foreground">Connect Synapse to your Google Ads, Gemini, and database.</p>
      </header>

      {sections.map((s) => (
        <section key={s.title} className="rounded-2xl border border-border bg-card-elevated p-6">
          <div className="flex items-center gap-3">
            <div className="grid h-10 w-10 place-items-center rounded-lg bg-primary/15 text-primary">
              <s.icon className="h-5 w-5" />
            </div>
            <div>
              <h2 className="font-display text-lg font-semibold">{s.title}</h2>
              <p className="text-xs text-muted-foreground">{s.desc}</p>
            </div>
          </div>
          <div className="mt-5 grid grid-cols-1 gap-3 md:grid-cols-2">
            {s.fields.map((f) => (
              <label key={f} className="flex flex-col gap-1.5">
                <span className="font-mono text-[10px] uppercase tracking-wider text-muted-foreground">{f}</span>
                <input
                  type="password"
                  placeholder="••••••••••••••••"
                  className="h-10 rounded-lg border border-border bg-background/40 px-3 font-mono text-sm focus:border-primary/60 focus:outline-none focus:ring-2 focus:ring-primary/20"
                />
              </label>
            ))}
          </div>
        </section>
      ))}

      <div className="flex justify-end">
        <button className="inline-flex items-center gap-2 rounded-lg bg-gradient-primary px-5 py-2.5 text-sm font-semibold text-primary-foreground shadow-glow">
          <Save className="h-4 w-4" /> Save changes
        </button>
      </div>
    </div>
  );
}

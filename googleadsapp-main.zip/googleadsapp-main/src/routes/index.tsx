import { createFileRoute, Link } from "@tanstack/react-router";
import { DollarSign, MousePointerClick, Eye, Target, Activity, ArrowRight, Sparkles } from "lucide-react";
import { Area, AreaChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis, Bar, BarChart, Cell, PieChart, Pie } from "recharts";
import { KpiCard } from "@/components/KpiCard";
import { campaigns, spendTrend, channelMix, agentRuns, agents } from "@/lib/mock-data";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/")({ component: Overview });

function Overview() {
  const totalSpend = campaigns.reduce((s, c) => s + c.cost, 0);
  const totalClicks = campaigns.reduce((s, c) => s + c.clicks, 0);
  const totalImpr = campaigns.reduce((s, c) => s + c.impressions, 0);
  const totalConv = campaigns.reduce((s, c) => s + c.conversions, 0);

  return (
    <div className="relative">
      <div className="absolute inset-x-0 top-0 h-64 grid-pattern opacity-40 [mask-image:linear-gradient(to_bottom,black,transparent)]" />
      <div className="relative mx-auto max-w-7xl space-y-8 p-6 md:p-8">
        {/* Hero */}
        <section className="flex flex-col gap-6 lg:flex-row lg:items-end lg:justify-between">
          <div>
            <div className="inline-flex items-center gap-2 rounded-full border border-primary/30 bg-primary/10 px-3 py-1 text-xs font-medium text-primary">
              <Sparkles className="h-3 w-3" /> Synapse cycle #1,284 completed 4m ago
            </div>
            <h1 className="mt-3 font-display text-4xl font-semibold tracking-tight md:text-5xl">
              Your campaigns are <span className="text-gradient">optimizing themselves</span>.
            </h1>
            <p className="mt-2 max-w-2xl text-sm text-muted-foreground">
              Three autonomous agents are monitoring spend, surgically removing waste, and rewriting ad copy in real time across your Google Ads account.
            </p>
          </div>
          <div className="flex gap-2">
            <Link to="/agents" className="inline-flex items-center gap-2 rounded-lg border border-border bg-card/60 px-4 py-2 text-sm font-medium hover:bg-card">
              View agents <ArrowRight className="h-4 w-4" />
            </Link>
            <Link to="/campaigns" className="inline-flex items-center gap-2 rounded-lg bg-gradient-primary px-4 py-2 text-sm font-semibold text-primary-foreground shadow-glow">
              Manage campaigns <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
        </section>

        {/* KPIs */}
        <section className="grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-4">
          <KpiCard label="Ad Spend (7d)" value={`$${totalSpend.toLocaleString(undefined,{maximumFractionDigits:0})}`} delta={-8.4} icon={DollarSign} accent="primary" hint="Saved $1,842 by agents" />
          <KpiCard label="Clicks" value={totalClicks.toLocaleString()} delta={12.6} icon={MousePointerClick} accent="accent" />
          <KpiCard label="Impressions" value={`${(totalImpr/1000).toFixed(0)}k`} delta={4.2} icon={Eye} accent="warning" />
          <KpiCard label="Conversions" value={totalConv.toLocaleString()} delta={18.9} icon={Target} accent="success" hint="ROAS 4.2x blended" />
        </section>

        {/* Charts */}
        <section className="grid grid-cols-1 gap-4 lg:grid-cols-3">
          <div className="lg:col-span-2 rounded-2xl border border-border bg-card-elevated p-6">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-display text-base font-semibold">Spend vs Conversions</h3>
                <p className="text-xs text-muted-foreground">Daily, last 7 days</p>
              </div>
              <div className="flex gap-4 text-xs">
                <span className="flex items-center gap-1.5"><span className="h-2 w-2 rounded-full bg-primary" /> Spend</span>
                <span className="flex items-center gap-1.5"><span className="h-2 w-2 rounded-full bg-accent" /> Conversions</span>
              </div>
            </div>
            <div className="mt-4 h-72">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={spendTrend}>
                  <defs>
                    <linearGradient id="g1" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="oklch(0.78 0.18 195)" stopOpacity={0.5} />
                      <stop offset="100%" stopColor="oklch(0.78 0.18 195)" stopOpacity={0} />
                    </linearGradient>
                    <linearGradient id="g2" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="oklch(0.66 0.22 305)" stopOpacity={0.5} />
                      <stop offset="100%" stopColor="oklch(0.66 0.22 305)" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid stroke="oklch(0.3 0.03 268 / 0.4)" strokeDasharray="3 3" vertical={false} />
                  <XAxis dataKey="day" stroke="oklch(0.68 0.03 260)" fontSize={11} tickLine={false} axisLine={false} />
                  <YAxis stroke="oklch(0.68 0.03 260)" fontSize={11} tickLine={false} axisLine={false} />
                  <Tooltip contentStyle={{ background: "oklch(0.2 0.025 268)", border: "1px solid oklch(0.3 0.03 268)", borderRadius: 12, fontSize: 12 }} />
                  <Area type="monotone" dataKey="spend" stroke="oklch(0.78 0.18 195)" strokeWidth={2} fill="url(#g1)" />
                  <Area type="monotone" dataKey="conversions" stroke="oklch(0.66 0.22 305)" strokeWidth={2} fill="url(#g2)" />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </div>

          <div className="rounded-2xl border border-border bg-card-elevated p-6">
            <h3 className="font-display text-base font-semibold">Channel Mix</h3>
            <p className="text-xs text-muted-foreground">Spend distribution</p>
            <div className="mt-4 h-48">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie data={channelMix} dataKey="value" nameKey="name" innerRadius={50} outerRadius={75} paddingAngle={3}>
                    {channelMix.map((_, i) => (
                      <Cell key={i} fill={["oklch(0.78 0.18 195)","oklch(0.66 0.22 305)","oklch(0.82 0.17 85)","oklch(0.78 0.18 155)"][i]} stroke="none" />
                    ))}
                  </Pie>
                  <Tooltip contentStyle={{ background: "oklch(0.2 0.025 268)", border: "1px solid oklch(0.3 0.03 268)", borderRadius: 12, fontSize: 12 }} />
                </PieChart>
              </ResponsiveContainer>
            </div>
            <ul className="mt-2 space-y-1.5 text-xs">
              {channelMix.map((c, i) => (
                <li key={c.name} className="flex items-center justify-between">
                  <span className="flex items-center gap-2">
                    <span className="h-2 w-2 rounded-full" style={{ background: ["oklch(0.78 0.18 195)","oklch(0.66 0.22 305)","oklch(0.82 0.17 85)","oklch(0.78 0.18 155)"][i] }} />
                    {c.name}
                  </span>
                  <span className="font-mono text-muted-foreground">{c.value}%</span>
                </li>
              ))}
            </ul>
          </div>
        </section>

        {/* Agents + activity */}
        <section className="grid grid-cols-1 gap-4 lg:grid-cols-3">
          {agents.map((a) => (
            <div key={a.key} className={cn("relative overflow-hidden rounded-2xl border border-border bg-card-elevated p-5")}>
              <div className={cn(
                "pointer-events-none absolute -right-12 -top-12 h-40 w-40 rounded-full blur-3xl",
                a.accent === "primary" && "bg-primary/30",
                a.accent === "accent" && "bg-accent/30",
                a.accent === "success" && "bg-success/30",
              )} />
              <div className="relative flex items-start justify-between">
                <div>
                  <span className="inline-flex items-center gap-1.5 rounded-full border border-success/30 bg-success/10 px-2 py-0.5 text-[10px] font-medium uppercase tracking-wider text-success">
                    <span className="h-1.5 w-1.5 rounded-full bg-success pulse-dot" /> active
                  </span>
                  <h3 className="mt-2 font-display text-lg font-semibold">{a.name}</h3>
                  <p className="text-xs text-muted-foreground">{a.role}</p>
                </div>
                <div className="text-right">
                  <p className="font-mono text-2xl font-semibold">{a.runs24h}</p>
                  <p className="text-[10px] uppercase tracking-wider text-muted-foreground">runs / 24h</p>
                </div>
              </div>
              <p className="relative mt-3 text-xs text-muted-foreground">{a.description}</p>
            </div>
          ))}
        </section>

        {/* Activity feed */}
        <section className="rounded-2xl border border-border bg-card-elevated">
          <div className="flex items-center justify-between border-b border-border px-6 py-4">
            <div className="flex items-center gap-2">
              <Activity className="h-4 w-4 text-primary" />
              <h3 className="font-display text-base font-semibold">Live Agent Activity</h3>
            </div>
            <Link to="/agents" className="text-xs text-primary hover:underline">View all</Link>
          </div>
          <ul className="divide-y divide-border">
            {agentRuns.slice(0, 5).map((r) => (
              <li key={r.id} className="flex items-center gap-4 px-6 py-3.5 text-sm">
                <span className={cn(
                  "rounded-md px-2 py-0.5 text-[10px] font-medium uppercase tracking-wider",
                  r.agent === "ROI Sentry" && "bg-primary/15 text-primary",
                  r.agent === "Intent Surgeon" && "bg-accent/15 text-accent",
                  r.agent === "Persuasion Architect" && "bg-success/15 text-success",
                )}>{r.agent}</span>
                <span className="flex-1 truncate">{r.action} · <span className="text-muted-foreground">{r.campaign}</span></span>
                <span className="hidden font-mono text-xs text-muted-foreground sm:inline">{r.impact}</span>
                <span className="text-xs text-muted-foreground">{r.at}</span>
              </li>
            ))}
          </ul>
        </section>
      </div>
    </div>
  );
}

import { createFileRoute } from "@tanstack/react-router";
import { Bot, Scissors, PenLine, Zap, Clock, CheckCircle2, AlertCircle } from "lucide-react";
import { agentRuns, agents } from "@/lib/mock-data";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/agents")({
  component: AgentsPage,
  head: () => ({ meta: [{ title: "Synapse Agents — Synapse" }, { name: "description", content: "Autonomous multi-agent system for Google Ads optimization." }] }),
});

const iconMap = { "roi-sentry": Bot, "intent-surgeon": Scissors, "persuasion-architect": PenLine };

function AgentsPage() {
  return (
    <div className="mx-auto max-w-7xl space-y-8 p-6 md:p-8">
      <header>
        <div className="inline-flex items-center gap-2 rounded-full border border-accent/30 bg-accent/10 px-3 py-1 text-xs font-medium text-accent">
          <Zap className="h-3 w-3" /> Orchestrator cycle every 15 minutes
        </div>
        <h1 className="mt-3 font-display text-3xl font-semibold tracking-tight md:text-4xl">Synapse Agents</h1>
        <p className="mt-1 max-w-2xl text-sm text-muted-foreground">
          Three specialized agents — coordinated by the orchestrator — analyze your account and execute real mutations on the Google Ads API.
        </p>
      </header>

      <section className="grid grid-cols-1 gap-5 lg:grid-cols-3">
        {agents.map((a) => {
          const Icon = iconMap[a.key as keyof typeof iconMap];
          return (
            <div key={a.key} className="relative overflow-hidden rounded-2xl border border-border bg-card-elevated p-6">
              <div className={cn(
                "pointer-events-none absolute -right-16 -top-16 h-48 w-48 rounded-full blur-3xl",
                a.accent === "primary" && "bg-primary/40",
                a.accent === "accent" && "bg-accent/40",
                a.accent === "success" && "bg-success/30",
              )} />
              <div className="relative">
                <div className={cn(
                  "grid h-12 w-12 place-items-center rounded-xl",
                  a.accent === "primary" && "bg-primary/20 text-primary",
                  a.accent === "accent" && "bg-accent/20 text-accent",
                  a.accent === "success" && "bg-success/20 text-success",
                )}>
                  <Icon className="h-6 w-6" />
                </div>
                <div className="mt-4 flex items-center gap-2">
                  <h3 className="font-display text-xl font-semibold">{a.name}</h3>
                  <span className="inline-flex items-center gap-1.5 rounded-full border border-success/30 bg-success/10 px-2 py-0.5 text-[10px] font-medium uppercase tracking-wider text-success">
                    <span className="h-1.5 w-1.5 rounded-full bg-success pulse-dot" /> active
                  </span>
                </div>
                <p className="text-xs uppercase tracking-wider text-muted-foreground">{a.role}</p>
                <p className="mt-3 text-sm text-muted-foreground">{a.description}</p>

                <div className="mt-5 grid grid-cols-2 gap-3 border-t border-border pt-4">
                  <div>
                    <p className="text-[10px] uppercase tracking-wider text-muted-foreground">Runs 24h</p>
                    <p className="font-mono text-xl font-semibold">{a.runs24h}</p>
                  </div>
                  <div>
                    <p className="text-[10px] uppercase tracking-wider text-muted-foreground">Saved 24h</p>
                    <p className="font-mono text-xl font-semibold text-success">
                      {a.saved ? `$${a.saved.toLocaleString()}` : "—"}
                    </p>
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </section>

      {/* Activity */}
      <section className="rounded-2xl border border-border bg-card-elevated">
        <div className="flex items-center justify-between border-b border-border px-6 py-4">
          <div>
            <h2 className="font-display text-lg font-semibold">Audit Log</h2>
            <p className="text-xs text-muted-foreground">Every decision, every mutation — fully traceable.</p>
          </div>
          <select className="rounded-md border border-border bg-background/40 px-2 py-1 text-xs">
            <option>All agents</option><option>ROI Sentry</option><option>Intent Surgeon</option><option>Persuasion Architect</option>
          </select>
        </div>
        <ul className="divide-y divide-border">
          {agentRuns.map((r) => (
            <li key={r.id} className="grid grid-cols-12 items-center gap-3 px-6 py-4 text-sm">
              <div className="col-span-2 flex items-center gap-2">
                <span className={cn(
                  "rounded-md px-2 py-0.5 text-[10px] font-medium uppercase tracking-wider",
                  r.agent === "ROI Sentry" && "bg-primary/15 text-primary",
                  r.agent === "Intent Surgeon" && "bg-accent/15 text-accent",
                  r.agent === "Persuasion Architect" && "bg-success/15 text-success",
                )}>{r.agent}</span>
              </div>
              <div className="col-span-5">
                <p className="font-medium">{r.action}</p>
                <p className="text-xs text-muted-foreground">{r.campaign}</p>
              </div>
              <div className="col-span-2 font-mono text-xs text-muted-foreground">{r.impact}</div>
              <div className="col-span-2">
                <span className={cn(
                  "inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[10px] font-medium uppercase tracking-wider",
                  r.status === "applied" && "bg-success/15 text-success",
                  r.status === "queued" && "bg-warning/15 text-warning",
                  r.status === "reverted" && "bg-destructive/15 text-destructive",
                )}>
                  {r.status === "applied" ? <CheckCircle2 className="h-3 w-3" /> : <AlertCircle className="h-3 w-3" />}
                  {r.status}
                </span>
              </div>
              <div className="col-span-1 flex items-center justify-end gap-1 text-xs text-muted-foreground">
                <Clock className="h-3 w-3" /> {r.at}
              </div>
            </li>
          ))}
        </ul>
      </section>
    </div>
  );
}

import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Pause, Play, MoreHorizontal, Search, Plus } from "lucide-react";
import { campaigns as initial, type Campaign } from "@/lib/mock-data";
import { cn } from "@/lib/utils";
import { CampaignDetailsSheet } from "@/components/CampaignDetailsSheet";

export const Route = createFileRoute("/campaigns")({
  component: CampaignsPage,
  head: () => ({ meta: [{ title: "Campaigns — Synapse" }, { name: "description", content: "Manage and monitor every Google Ads campaign." }] }),
});

function CampaignsPage() {
  const [rows, setRows] = useState<Campaign[]>(initial);
  const [q, setQ] = useState("");
  const [filter, setFilter] = useState<"ALL" | "ENABLED" | "PAUSED">("ALL");
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const selected = rows.find((c) => c.id === selectedId) ?? null;

  const filtered = rows.filter((c) =>
    (filter === "ALL" || c.status === filter) &&
    c.name.toLowerCase().includes(q.toLowerCase()),
  );

  const toggle = (id: string) =>
    setRows((r) => r.map((c) => (c.id === id ? { ...c, status: c.status === "ENABLED" ? "PAUSED" : "ENABLED" } : c)));

  return (
    <div className="mx-auto max-w-7xl space-y-6 p-6 md:p-8">
      <header className="flex flex-col gap-4 md:flex-row md:items-end md:justify-between">
        <div>
          <h1 className="font-display text-3xl font-semibold tracking-tight">Campaigns</h1>
          <p className="text-sm text-muted-foreground">Direct control over every Google Ads campaign — agents stay in sync.</p>
        </div>
        <button className="inline-flex items-center gap-2 rounded-lg bg-gradient-primary px-4 py-2 text-sm font-semibold text-primary-foreground shadow-glow">
          <Plus className="h-4 w-4" /> New campaign
        </button>
      </header>

      <div className="flex flex-wrap items-center gap-2">
        <div className="relative flex-1 min-w-64">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <input
            value={q} onChange={(e) => setQ(e.target.value)}
            placeholder="Filter campaigns…"
            className="h-10 w-full rounded-lg border border-border bg-card/60 pl-9 pr-3 text-sm focus:border-primary/60 focus:outline-none focus:ring-2 focus:ring-primary/20"
          />
        </div>
        <div className="flex rounded-lg border border-border bg-card/60 p-1">
          {(["ALL", "ENABLED", "PAUSED"] as const).map((f) => (
            <button
              key={f} onClick={() => setFilter(f)}
              className={cn("rounded-md px-3 py-1.5 text-xs font-medium transition", filter === f ? "bg-gradient-primary text-primary-foreground" : "text-muted-foreground hover:text-foreground")}
            >{f}</button>
          ))}
        </div>
      </div>

      <div className="overflow-hidden rounded-2xl border border-border bg-card-elevated">
        <table className="w-full text-sm">
          <thead className="border-b border-border bg-background/30 text-xs uppercase tracking-wider text-muted-foreground">
            <tr>
              <th className="px-4 py-3 text-left font-medium">Campaign</th>
              <th className="px-4 py-3 text-left font-medium">Status</th>
              <th className="px-4 py-3 text-right font-medium">Budget</th>
              <th className="px-4 py-3 text-right font-medium">Clicks</th>
              <th className="px-4 py-3 text-right font-medium">Impr.</th>
              <th className="px-4 py-3 text-right font-medium">CTR</th>
              <th className="px-4 py-3 text-right font-medium">Spend</th>
              <th className="px-4 py-3 text-right font-medium">ROAS</th>
              <th className="px-4 py-3 text-right font-medium">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-border">
            {filtered.map((c) => (
              <tr key={c.id} onClick={() => setSelectedId(c.id)} className="group cursor-pointer transition hover:bg-background/30 data-[selected=true]:bg-primary/5" data-selected={c.id === selectedId}>
                <td className="px-4 py-3">
                  <div className="font-medium">{c.name}</div>
                  <div className="font-mono text-[10px] text-muted-foreground">#{c.id}</div>
                </td>
                <td className="px-4 py-3">
                  <span className={cn(
                    "inline-flex items-center gap-1.5 rounded-full px-2 py-0.5 text-[10px] font-medium uppercase tracking-wider",
                    c.status === "ENABLED" && "bg-success/15 text-success",
                    c.status === "PAUSED" && "bg-warning/15 text-warning",
                    c.status === "REMOVED" && "bg-destructive/15 text-destructive",
                  )}>
                    <span className={cn("h-1.5 w-1.5 rounded-full", c.status === "ENABLED" ? "bg-success pulse-dot" : "bg-warning")} />
                    {c.status}
                  </span>
                </td>
                <td className="px-4 py-3 text-right font-mono">${c.budget}/d</td>
                <td className="px-4 py-3 text-right font-mono">{c.clicks.toLocaleString()}</td>
                <td className="px-4 py-3 text-right font-mono">{c.impressions.toLocaleString()}</td>
                <td className="px-4 py-3 text-right font-mono">{c.ctr.toFixed(2)}%</td>
                <td className="px-4 py-3 text-right font-mono">${c.cost.toLocaleString()}</td>
                <td className="px-4 py-3 text-right">
                  <span className={cn("font-mono font-semibold", c.roas >= 3 ? "text-success" : c.roas >= 1.5 ? "text-warning" : "text-destructive")}>
                    {c.roas.toFixed(1)}x
                  </span>
                </td>
                <td className="px-4 py-3" onClick={(e) => e.stopPropagation()}>
                  <div className="flex items-center justify-end gap-1">
                    <button
                      onClick={() => toggle(c.id)}
                      disabled={c.status === "REMOVED"}
                      className="grid h-8 w-8 place-items-center rounded-md border border-border hover:bg-background/50 disabled:opacity-30"
                      title={c.status === "ENABLED" ? "Pause" : "Enable"}
                    >
                      {c.status === "ENABLED" ? <Pause className="h-3.5 w-3.5" /> : <Play className="h-3.5 w-3.5" />}
                    </button>
                    <button className="grid h-8 w-8 place-items-center rounded-md border border-border hover:bg-background/50">
                      <MoreHorizontal className="h-3.5 w-3.5" />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <CampaignDetailsSheet
        campaign={selected}
        onClose={() => setSelectedId(null)}
        onToggle={toggle}
      />
    </div>
  );
}

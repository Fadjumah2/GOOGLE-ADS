import { createFileRoute } from "@tanstack/react-router";
import { Bar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis, Line, LineChart } from "recharts";
import { Download, Calendar } from "lucide-react";
import { spendTrend, campaigns } from "@/lib/mock-data";

export const Route = createFileRoute("/reports")({
  component: ReportsPage,
  head: () => ({ meta: [{ title: "Reports — Synapse" }, { name: "description", content: "Deep performance reports across campaigns and time." }] }),
});

function ReportsPage() {
  return (
    <div className="mx-auto max-w-7xl space-y-6 p-6 md:p-8">
      <header className="flex flex-col gap-4 md:flex-row md:items-end md:justify-between">
        <div>
          <h1 className="font-display text-3xl font-semibold tracking-tight">Reports</h1>
          <p className="text-sm text-muted-foreground">Daily performance across all campaigns.</p>
        </div>
        <div className="flex gap-2">
          <button className="inline-flex items-center gap-2 rounded-lg border border-border bg-card/60 px-3 py-2 text-sm">
            <Calendar className="h-4 w-4" /> Last 7 days
          </button>
          <button className="inline-flex items-center gap-2 rounded-lg border border-border bg-card/60 px-3 py-2 text-sm">
            <Download className="h-4 w-4" /> Export CSV
          </button>
        </div>
      </header>

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
        <div className="rounded-2xl border border-border bg-card-elevated p-6">
          <h3 className="font-display text-base font-semibold">Clicks per day</h3>
          <div className="mt-4 h-64">
            <ResponsiveContainer>
              <BarChart data={spendTrend}>
                <CartesianGrid stroke="oklch(0.3 0.03 268 / 0.4)" strokeDasharray="3 3" vertical={false} />
                <XAxis dataKey="day" stroke="oklch(0.68 0.03 260)" fontSize={11} tickLine={false} axisLine={false} />
                <YAxis stroke="oklch(0.68 0.03 260)" fontSize={11} tickLine={false} axisLine={false} />
                <Tooltip contentStyle={{ background: "oklch(0.2 0.025 268)", border: "1px solid oklch(0.3 0.03 268)", borderRadius: 12, fontSize: 12 }} />
                <Bar dataKey="clicks" fill="oklch(0.78 0.18 195)" radius={[6,6,0,0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
        <div className="rounded-2xl border border-border bg-card-elevated p-6">
          <h3 className="font-display text-base font-semibold">Conversions trend</h3>
          <div className="mt-4 h-64">
            <ResponsiveContainer>
              <LineChart data={spendTrend}>
                <CartesianGrid stroke="oklch(0.3 0.03 268 / 0.4)" strokeDasharray="3 3" vertical={false} />
                <XAxis dataKey="day" stroke="oklch(0.68 0.03 260)" fontSize={11} tickLine={false} axisLine={false} />
                <YAxis stroke="oklch(0.68 0.03 260)" fontSize={11} tickLine={false} axisLine={false} />
                <Tooltip contentStyle={{ background: "oklch(0.2 0.025 268)", border: "1px solid oklch(0.3 0.03 268)", borderRadius: 12, fontSize: 12 }} />
                <Line type="monotone" dataKey="conversions" stroke="oklch(0.66 0.22 305)" strokeWidth={3} dot={{ r: 4, fill: "oklch(0.66 0.22 305)" }} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      <div className="overflow-hidden rounded-2xl border border-border bg-card-elevated">
        <div className="border-b border-border px-6 py-4">
          <h2 className="font-display text-base font-semibold">Per-campaign breakdown</h2>
        </div>
        <table className="w-full text-sm">
          <thead className="border-b border-border bg-background/30 text-xs uppercase tracking-wider text-muted-foreground">
            <tr>
              <th className="px-4 py-3 text-left font-medium">Campaign</th>
              <th className="px-4 py-3 text-right font-medium">Impr.</th>
              <th className="px-4 py-3 text-right font-medium">Clicks</th>
              <th className="px-4 py-3 text-right font-medium">CTR</th>
              <th className="px-4 py-3 text-right font-medium">Conv.</th>
              <th className="px-4 py-3 text-right font-medium">Spend</th>
              <th className="px-4 py-3 text-right font-medium">CPA</th>
              <th className="px-4 py-3 text-right font-medium">ROAS</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-border">
            {campaigns.map((c) => (
              <tr key={c.id} className="hover:bg-background/30">
                <td className="px-4 py-3 font-medium">{c.name}</td>
                <td className="px-4 py-3 text-right font-mono">{c.impressions.toLocaleString()}</td>
                <td className="px-4 py-3 text-right font-mono">{c.clicks.toLocaleString()}</td>
                <td className="px-4 py-3 text-right font-mono">{c.ctr.toFixed(2)}%</td>
                <td className="px-4 py-3 text-right font-mono">{c.conversions}</td>
                <td className="px-4 py-3 text-right font-mono">${c.cost.toLocaleString()}</td>
                <td className="px-4 py-3 text-right font-mono">${(c.cost/Math.max(c.conversions,1)).toFixed(2)}</td>
                <td className="px-4 py-3 text-right font-mono font-semibold text-success">{c.roas.toFixed(1)}x</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

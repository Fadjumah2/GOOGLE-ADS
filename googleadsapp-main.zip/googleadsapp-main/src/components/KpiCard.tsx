import { ArrowDownRight, ArrowUpRight } from "lucide-react";
import type { LucideIcon } from "lucide-react";
import { cn } from "@/lib/utils";

type Props = {
  label: string;
  value: string;
  delta: number;
  icon: LucideIcon;
  accent?: "primary" | "accent" | "success" | "warning";
  hint?: string;
};

const accentMap = {
  primary: "from-primary/30 to-primary/0 text-primary",
  accent: "from-accent/30 to-accent/0 text-accent",
  success: "from-success/30 to-success/0 text-success",
  warning: "from-warning/30 to-warning/0 text-warning",
};

export function KpiCard({ label, value, delta, icon: Icon, accent = "primary", hint }: Props) {
  const up = delta >= 0;
  return (
    <div className="group relative overflow-hidden rounded-2xl border border-border bg-card-elevated p-5 transition hover:border-primary/40">
      <div className={cn("pointer-events-none absolute -right-10 -top-10 h-32 w-32 rounded-full bg-gradient-to-br opacity-60 blur-2xl", accentMap[accent])} />
      <div className="relative flex items-start justify-between">
        <div>
          <p className="text-xs font-medium uppercase tracking-wider text-muted-foreground">{label}</p>
          <p className="mt-2 font-display text-3xl font-semibold tracking-tight">{value}</p>
          {hint && <p className="mt-1 text-xs text-muted-foreground">{hint}</p>}
        </div>
        <div className={cn("grid h-10 w-10 place-items-center rounded-lg bg-background/40 backdrop-blur", accentMap[accent].split(" ").pop())}>
          <Icon className="h-5 w-5" />
        </div>
      </div>
      <div className="relative mt-4 flex items-center gap-1.5 text-xs">
        <span className={cn("inline-flex items-center gap-0.5 rounded-md px-1.5 py-0.5 font-medium", up ? "bg-success/15 text-success" : "bg-destructive/15 text-destructive")}>
          {up ? <ArrowUpRight className="h-3 w-3" /> : <ArrowDownRight className="h-3 w-3" />}
          {Math.abs(delta).toFixed(1)}%
        </span>
        <span className="text-muted-foreground">vs last 7d</span>
      </div>
    </div>
  );
}

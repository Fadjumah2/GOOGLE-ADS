import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetDescription } from "@/components/ui/sheet";
import { type Campaign, agentRuns } from "@/lib/mock-data";
import { cn } from "@/lib/utils";
import { Activity, DollarSign, MousePointerClick, Target, TrendingUp, Eye, Sparkles, Pause, Play } from "lucide-react";
import { Area, AreaChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";

type Props = {
  campaign: Campaign | null;
  onClose: () => void;
  onToggle: (id: string) => void;
};

const sparkData = (seed: number) =>
  Array.from({ length: 14 }, (_, i) => ({
    d: i,
    v: Math.round(seed * (0.6 + Math.sin(i / 2 + seed) * 0.18 + Math.random() * 0.25)),
  }));

export function CampaignDetailsSheet({ campaign, onClose, onToggle }: Props) {
  const open = !!campaign;
  if (!campaign) {
    return <Sheet open={open} onOpenChange={(o) => !o && onClose()} />;
  }

  const cpc = campaign.cost / Math.max(campaign.clicks, 1);
  const cpa = campaign.cost / Math.max(campaign.conversions, 1);
  const convRate = (campaign.conversions / Math.max(campaign.clicks, 1)) * 100;
  const revenue = campaign.cost * campaign.roas;
  const related = agentRuns.filter((r) => r.campaign === campaign.name).slice(0, 6);
  const trend = sparkData(campaign.clicks / 14);

  const metrics = [
    { label: "Spend", value: `$${campaign.cost.toLocaleString()}`, icon: DollarSign, accent: "text-primary" },
    { label: "Revenue", value: `$${revenue.toLocaleString(undefined, { maximumFractionDigits: 0 })}`, icon: TrendingUp, accent: "text-success" },
    { label: "Conversions", value: campaign.conversions.toLocaleString(), icon: Target, accent: "text-accent" },
    { label: "Clicks", value: campaign.clicks.toLocaleString(), icon: MousePointerClick, accent: "text-foreground" },
    { label: "Impressions", value: campaign.impressions.toLocaleString(), icon: Eye, accent: "text-muted-foreground" },
    { label: "CTR", value: `${campaign.ctr.toFixed(2)}%`, icon: Activity, accent: "text-foreground" },
    { label: "Avg. CPC", value: `$${cpc.toFixed(2)}`, icon: DollarSign, accent: "text-foreground" },
    { label: "Cost / Conv.", value: `$${cpa.toFixed(2)}`, icon: Target, accent: "text-foreground" },
  ];

  return (
    <Sheet open={open} onOpenChange={(o) => !o && onClose()}>
      <SheetContent className="w-full overflow-y-auto border-l border-border bg-card-elevated p-0 sm:max-w-xl">
        <div className="border-b border-border bg-gradient-to-br from-primary/10 via-transparent to-accent/10 p-6">
          <div className="flex items-center gap-2">
            <span className={cn(
              "inline-flex items-center gap-1.5 rounded-full px-2 py-0.5 text-[10px] font-medium uppercase tracking-wider",
              campaign.status === "ENABLED" && "bg-success/15 text-success",
              campaign.status === "PAUSED" && "bg-warning/15 text-warning",
              campaign.status === "REMOVED" && "bg-destructive/15 text-destructive",
            )}>
              <span className={cn("h-1.5 w-1.5 rounded-full", campaign.status === "ENABLED" ? "bg-success pulse-dot" : "bg-warning")} />
              {campaign.status}
            </span>
            <span className="font-mono text-[10px] text-muted-foreground">#{campaign.id}</span>
          </div>
          <SheetHeader className="mt-3 space-y-1">
            <SheetTitle className="font-display text-2xl tracking-tight">{campaign.name}</SheetTitle>
            <SheetDescription>
              ${campaign.budget}/day budget · ROAS{" "}
              <span className={cn("font-mono font-semibold", campaign.roas >= 3 ? "text-success" : campaign.roas >= 1.5 ? "text-warning" : "text-destructive")}>
                {campaign.roas.toFixed(1)}x
              </span>{" "}
              · {convRate.toFixed(1)}% conv. rate
            </SheetDescription>
          </SheetHeader>

          <div className="mt-4 flex gap-2">
            <button
              onClick={() => onToggle(campaign.id)}
              className="inline-flex items-center gap-1.5 rounded-lg bg-gradient-primary px-3 py-1.5 text-xs font-semibold text-primary-foreground shadow-glow"
            >
              {campaign.status === "ENABLED" ? <><Pause className="h-3.5 w-3.5" /> Pause</> : <><Play className="h-3.5 w-3.5" /> Enable</>}
            </button>
            <button className="inline-flex items-center gap-1.5 rounded-lg border border-border bg-background/30 px-3 py-1.5 text-xs font-medium hover:bg-background/50">
              Edit budget
            </button>
            <button className="inline-flex items-center gap-1.5 rounded-lg border border-border bg-background/30 px-3 py-1.5 text-xs font-medium hover:bg-background/50">
              View in Google Ads
            </button>
          </div>
        </div>

        <div className="space-y-6 p-6">
          <section>
            <div className="mb-3 flex items-center justify-between">
              <h3 className="text-sm font-semibold tracking-tight">Performance · last 14 days</h3>
              <span className="text-xs text-muted-foreground">Daily clicks</span>
            </div>
            <div className="h-32 rounded-xl border border-border bg-background/30 p-2">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={trend} margin={{ top: 4, right: 4, left: 4, bottom: 0 }}>
                  <defs>
                    <linearGradient id="campSpark" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="oklch(var(--primary))" stopOpacity={0.5} />
                      <stop offset="100%" stopColor="oklch(var(--primary))" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <XAxis dataKey="d" hide />
                  <YAxis hide />
                  <Tooltip
                    contentStyle={{ background: "oklch(var(--card-elevated))", border: "1px solid oklch(var(--border))", borderRadius: 8, fontSize: 11 }}
                    labelFormatter={(l) => `Day ${l as number + 1}`}
                  />
                  <Area type="monotone" dataKey="v" stroke="oklch(var(--primary))" strokeWidth={2} fill="url(#campSpark)" />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </section>

          <section>
            <h3 className="mb-3 text-sm font-semibold tracking-tight">Metrics</h3>
            <div className="grid grid-cols-2 gap-2">
              {metrics.map((m) => (
                <div key={m.label} className="rounded-xl border border-border bg-background/30 p-3">
                  <div className="flex items-center gap-1.5 text-[10px] uppercase tracking-wider text-muted-foreground">
                    <m.icon className={cn("h-3 w-3", m.accent)} />
                    {m.label}
                  </div>
                  <div className="mt-1 font-mono text-base font-semibold">{m.value}</div>
                </div>
              ))}
            </div>
          </section>

          <section>
            <div className="mb-3 flex items-center gap-2">
              <Sparkles className="h-3.5 w-3.5 text-accent" />
              <h3 className="text-sm font-semibold tracking-tight">Recent agent actions</h3>
            </div>
            {related.length === 0 ? (
              <div className="rounded-xl border border-dashed border-border bg-background/20 p-6 text-center text-xs text-muted-foreground">
                No agent activity on this campaign in the last 24h.
              </div>
            ) : (
              <ul className="space-y-2">
                {related.map((r) => (
                  <li key={r.id} className="rounded-xl border border-border bg-background/30 p-3">
                    <div className="flex items-start justify-between gap-3">
                      <div className="min-w-0">
                        <div className="flex items-center gap-2">
                          <span className="rounded-md bg-accent/15 px-1.5 py-0.5 text-[10px] font-medium text-accent">{r.agent}</span>
                          <span className="text-[10px] text-muted-foreground">{r.at}</span>
                        </div>
                        <div className="mt-1 text-sm">{r.action}</div>
                        <div className="mt-0.5 text-xs text-muted-foreground">{r.impact}</div>
                      </div>
                      <span className={cn(
                        "shrink-0 rounded-full px-2 py-0.5 text-[10px] font-medium uppercase tracking-wider",
                        r.status === "applied" && "bg-success/15 text-success",
                        r.status === "queued" && "bg-warning/15 text-warning",
                        r.status === "reverted" && "bg-destructive/15 text-destructive",
                      )}>{r.status}</span>
                    </div>
                  </li>
                ))}
              </ul>
            )}
          </section>
        </div>
      </SheetContent>
    </Sheet>
  );
}

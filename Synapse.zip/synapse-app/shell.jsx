// Synapse — Sidebar + Topbar shell (responsive + collapsible)
const { useState: uS1, useEffect: uE1 } = React;

const NAV = [
  { group: "Overview", items: [
    { id: "dashboard", label: "Dashboard", icon: "dashboard" }
  ]},
  { group: "Agent", items: [
    { id: "autopilot", label: "Autopilot", icon: "autopilot", live: true },
    { id: "chat", label: "Synapse AI", icon: "ai" },
    { id: "audit", label: "Audit log", icon: "inbox" }
  ]},
  { group: "Content", items: [
    { id: "posts", label: "Posts", icon: "posts" },
    { id: "reviews", label: "Reviews", icon: "reviews", badge: "3" },
    { id: "media", label: "Media", icon: "media" }
  ]},
  { group: "Profile", items: [
    { id: "services", label: "Services", icon: "services" },
    { id: "analytics", label: "Analytics", icon: "analytics" }
  ]}
];

function Sidebar({ view, setView, open, onClose, isMobile }) {
  // Desktop: slide in/out horizontally (width 236 ↔ 0). Mobile: fixed drawer.
  const width = 236;

  const base = {
    width,
    flexShrink: 0,
    background: T.bgSoft,
    borderRight: `1px solid ${T.line}`,
    display: "flex",
    flexDirection: "column",
    height: "100vh",
    transition: "transform 0.25s ease, margin-left 0.25s ease"
  };

  const desktopStyle = {
    ...base,
    position: "sticky",
    top: 0,
    marginLeft: open ? 0 : -width,
    transform: "translateX(0)"
  };

  const mobileStyle = {
    ...base,
    position: "fixed",
    top: 0, left: 0,
    zIndex: 40,
    boxShadow: open ? "0 10px 40px oklch(0.18 0.01 60 / 0.15)" : "none",
    transform: open ? "translateX(0)" : `translateX(-${width}px)`,
    marginLeft: 0
  };

  return (
    <aside style={isMobile ? mobileStyle : desktopStyle}>
      {/* Logo */}
      <div style={{ padding: "20px 20px 24px", display: "flex", alignItems: "center", gap: 10, justifyContent: "space-between" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          <div style={{
            width: 26, height: 26, borderRadius: 7,
            background: T.ink,
            display: "flex", alignItems: "center", justifyContent: "center",
            position: "relative"
          }}>
            <div style={{ width: 11, height: 11, borderRadius: "50%", border: `1.5px solid ${T.accent}` }} />
            <div style={{ position: "absolute", width: 4, height: 4, borderRadius: "50%", background: T.accent }} />
          </div>
          <div>
            <div style={{ fontFamily: T.fontDisp, fontSize: 20, lineHeight: 1, letterSpacing: "-0.01em" }}>Synapse</div>
            <div style={{ fontFamily: T.fontMono, fontSize: 9, letterSpacing: "0.12em", textTransform: "uppercase", color: T.ink60, marginTop: 2 }}>GBP Command</div>
          </div>
        </div>
        {isMobile && (
          <button onClick={onClose} aria-label="Close menu" style={{
            width: 30, height: 30, borderRadius: 6,
            border: `1px solid ${T.line}`, background: T.bgElev,
            display: "flex", alignItems: "center", justifyContent: "center", cursor: "pointer"
          }}>
            <Ico name="x" size={14} color={T.ink70} />
          </button>
        )}
      </div>

      {/* Business picker */}
      <div style={{ margin: "0 12px 20px", padding: "10px 12px", border: `1px solid ${T.line}`, borderRadius: 8, background: T.bgElev, cursor: "pointer" }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
          <div>
            <div style={{ fontSize: 12, fontWeight: 500, lineHeight: 1.2 }}>Eritage ENT Care</div>
            <Mono size={10} style={{ marginTop: 2 }}>Entebbe · verified</Mono>
          </div>
          <Ico name="arrowDown" size={14} color={T.ink60} />
        </div>
      </div>

      {/* Nav */}
      <nav style={{ flex: 1, padding: "0 10px", overflowY: "auto" }}>
        {NAV.map(section => (
          <div key={section.group} style={{ marginBottom: 16 }}>
            <div style={{ padding: "6px 10px" }}>
              <Label>{section.group}</Label>
            </div>
            {section.items.map(it => {
              const active = view === it.id;
              return (
                <div key={it.id} onClick={() => setView(it.id)} style={{
                  padding: "7px 10px", borderRadius: 6, marginBottom: 1,
                  display: "flex", alignItems: "center", gap: 10,
                  fontSize: 13, fontWeight: 500,
                  cursor: "pointer",
                  background: active ? T.bgElev : "transparent",
                  color: active ? T.ink : T.ink70,
                  border: `1px solid ${active ? T.line : "transparent"}`,
                  transition: "background 0.12s"
                }}
                onMouseOver={e => !active && (e.currentTarget.style.background = "oklch(0.94 0.008 75)")}
                onMouseOut={e => !active && (e.currentTarget.style.background = "transparent")}
                >
                  <Ico name={it.icon} size={15} color={active ? T.accent : T.ink60} />
                  <span style={{ flex: 1 }}>{it.label}</span>
                  {it.live && (
                    <span style={{ width: 6, height: 6, borderRadius: "50%", background: T.good, boxShadow: `0 0 0 3px ${T.goodSoft}` }} />
                  )}
                  {it.badge && (
                    <Mono size={10} color={T.accent} style={{ background: T.accentSoft, padding: "1px 6px", borderRadius: 3 }}>{it.badge}</Mono>
                  )}
                </div>
              );
            })}
          </div>
        ))}
      </nav>

      {/* Footer */}
      <div style={{ padding: 14, borderTop: `1px solid ${T.line}`, fontSize: 12 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
          <div style={{ width: 28, height: 28, borderRadius: "50%", background: T.accent, color: T.bg, display: "flex", alignItems: "center", justifyContent: "center", fontWeight: 600, fontSize: 11 }}>HM</div>
          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{ fontSize: 12, fontWeight: 500, lineHeight: 1.2, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>Hassan M.</div>
            <Mono size={10}>Owner</Mono>
          </div>
          <Ico name="settings" size={14} color={T.ink60} />
        </div>
      </div>
    </aside>
  );
}

function Topbar({ view, title, sub, right, onMenu, sidebarOpen, isMobile }) {
  return (
    <div style={{
      position: "sticky", top: 0, zIndex: 10,
      background: `color-mix(in oklch, ${T.bg} 88%, transparent)`,
      backdropFilter: "blur(12px)",
      borderBottom: `1px solid ${T.line}`,
      padding: isMobile ? "14px 18px" : "16px 32px",
      display: "flex", alignItems: "center", justifyContent: "space-between",
      gap: 12
    }}>
      <div style={{ display: "flex", alignItems: "center", gap: 12, minWidth: 0 }}>
        {/* Hamburger / collapse toggle */}
        <button onClick={onMenu} aria-label={sidebarOpen ? "Hide sidebar" : "Show sidebar"} style={{
          width: 36, height: 36, borderRadius: 8,
          border: `1px solid ${T.line}`,
          background: sidebarOpen ? T.bgSoft : T.bgElev,
          display: "flex", alignItems: "center", justifyContent: "center",
          cursor: "pointer", flexShrink: 0, padding: 0,
          transition: "background 0.15s"
        }}>
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke={T.ink} strokeWidth="1.75" strokeLinecap="round">
            <line x1="4" y1="7" x2="20" y2="7" />
            <line x1="4" y1="12" x2="20" y2="12" />
            <line x1="4" y1="17" x2="20" y2="17" />
          </svg>
        </button>

        <div style={{ minWidth: 0 }}>
          {!isMobile && (
            <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
              <Mono size={11}>synapse / {view}</Mono>
              <span style={{ width: 6, height: 6, borderRadius: "50%", background: T.good }} />
              <Mono size={10} color={T.good}>AUTOPILOT ON</Mono>
            </div>
          )}
          <div style={{
            fontFamily: T.fontDisp,
            fontSize: isMobile ? 22 : 28,
            letterSpacing: "-0.02em",
            marginTop: isMobile ? 0 : 4,
            lineHeight: 1.1,
            overflow: "hidden",
            textOverflow: "ellipsis",
            whiteSpace: "nowrap"
          }}>{title}</div>
          {sub && !isMobile && <div style={{ fontSize: 13, color: T.ink70, marginTop: 4 }}>{sub}</div>}
          {isMobile && (
            <div style={{ display: "flex", alignItems: "center", gap: 6, marginTop: 2 }}>
              <span style={{ width: 5, height: 5, borderRadius: "50%", background: T.good }} />
              <Mono size={9} color={T.good}>AUTOPILOT ON</Mono>
            </div>
          )}
        </div>
      </div>
      <div style={{ display: "flex", gap: 8, alignItems: "center", flexShrink: 0 }}>
        {right}
      </div>
    </div>
  );
}

window.Sidebar = Sidebar;
window.Topbar = Topbar;
